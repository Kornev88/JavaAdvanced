package com.company;

public abstract class Shape {
    public abstract double area();
}

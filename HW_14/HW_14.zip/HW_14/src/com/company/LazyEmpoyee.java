package com.company;

public class LazyEmpoyee extends Employee {

    public LazyEmpoyee(String name,double salary){
        super(name,salary);
    }
}
